def get_words(text):
    import re
    return re.findall(r'\w+', text, re.UNICODE)


def make_chunks(text, size=40, overlap=0):
    if overlap >= size:
        raise ValueError('overlap must be smaller than size')

    words = text.split()
    step = size - overlap
    answer = []

    for start in range(0, len(words), step):
        part = words[start:start + size]
        if part:
            answer.append((start, ' '.join(part)))
        if start + size >= len(words):
            break
    return answer


def make_sentence_chunks(text):
    sentences = text.replace('!', '.').replace('?', '.').split('.')
    answer = []
    current = []

    for sentence in sentences:
        new_words = sentence.split()
        if current and len(current) + len(new_words) > 40:
            answer.append(' '.join(current))
            current = []
        current += new_words

    if current:
        answer.append(' '.join(current))
    return list(enumerate(answer))


def make_documents():
    def make_long(text):
        copy = text
        while len(text.split()) < 160:
            text += ' ' + copy
        return text

    return {
        'D1': make_long('Library rule: three books may be borrowed for fourteen days. Exception: final-year students may borrow five books.'),
        'D2': make_long('Lab rule: safety glasses and closed shoes are required. Exception: visitors need staff supervision.'),
        'D3': make_long('Attendance rule: seventy-five percent attendance is required. Exception: approved medical leave may be considered.'),
        'D4': 'Network rule: passwords must be private. Report suspicious messages to the help desk.',
        'D5': 'Assessment rule: assignments need citations and must be submitted before the deadline.'
    }


def make_corpus(method):
    all_chunks = []
    for document_id, document in make_documents().items():
        if method == 'sentence':
            parts = make_sentence_chunks(document)
        else:
            overlap = 0 if method == 'window0' else 10
            parts = make_chunks(document, 40, overlap)

        for number, part in enumerate(parts, 1):
            start, text = part
            chunk_id = document_id + '-' + method + '-' + str(number)
            all_chunks.append((chunk_id, document_id, start, text))
    return all_chunks


def make_tfidf(texts):
    import math
    from collections import Counter

    words = []
    for text in texts:
        words.append(get_words(text.lower()))

    document_count = Counter()
    for row in words:
        for word in set(row):
            document_count[word] += 1

    vectors = []
    for row in words:
        count = Counter(row)
        vector = {}
        for word in count:
            term_frequency = count[word] / max(len(row), 1)
            inverse_frequency = math.log((1 + len(texts)) / (1 + document_count[word]))
            vector[word] = term_frequency * inverse_frequency
        vectors.append(vector)
    return vectors


def compare(first, second):
    import math
    total = 0
    for word in set(first) | set(second):
        total += first.get(word, 0) * second.get(word, 0)

    length = math.sqrt(sum(x * x for x in first.values()))
    length *= math.sqrt(sum(x * x for x in second.values()))
    return total / length if length else 0


def search(question, chunks):
    texts = []
    for chunk in chunks:
        texts.append(chunk[3])
    texts.append(question)

    vectors = make_tfidf(texts)
    results = []
    question_vector = vectors[-1]

    for number, chunk in enumerate(chunks):
        value = compare(question_vector, vectors[number])
        results.append((value, chunk))

    results.sort(reverse=True, key=lambda x: x[0])
    return results[:3]


def faq_answer(question):
    question = question.lower()
    if 'ai' in question:
        return 'AI performs intelligent tasks. Source: AI notes'
    if 'tf-idf' in question:
        return 'TF-IDF finds important words. Source: IR notes'
    return 'Please confirm or rephrase your question.'


def main():
    import csv
    import time

    print('TASK 1')
    examples = ['Hello, AI!', "don't stop", 'help@example.com', 'CS4944', '', 'یہ مصنوعی ذہانت ہے']
    for example in examples:
        print(example, get_words(example), len(get_words(example)))
    print(faq_answer('What is AI?'))
    print(faq_answer('Tell me about machines'))
    print(faq_answer(''))

    print('\nTASK 2')
    for method in ['window0', 'window10', 'sentence']:
        chunks = make_corpus(method)
        sizes = [len(chunk[3].split()) for chunk in chunks]
        repeated = 0
        for first, second in zip(chunks, chunks[1:]):
            repeated += len(set(first[3].split()) & set(second[3].split()))
        average = round(sum(sizes) / len(sizes), 1)
        print(method, len(chunks), average, 'repeated:', repeated)

    print('Document sizes:', {k: len(v.split()) for k, v in make_documents().items()})
    print('Empty:', make_chunks(''))
    print('Short:', make_chunks('short text'))
    try:
        make_chunks('test', 40, 40)
    except ValueError as error:
        print('Invalid overlap:', error)

    questions = [
        ('How many books may a final-year student borrow?', 'D1'),
        ('What must be worn in the lab?', 'D2'),
        ('What attendance is required?', 'D3'),
        ('How is a chemical spill reported?', 'D2'),
        ('What is the password rule?', 'D4'),
        ('Are citations required?', 'D5'),
        ('Can medical leave be considered?', 'D3'),
        ('Who confirms the library exception?', 'D1')
    ]
    development = questions[:4]
    final = questions[4:]
    unknown = ['What is the cafeteria menu?', 'Which bus goes to campus?']

    print('\nTASK 3')
    with open('lab6_results.csv', 'w', newline='', encoding='utf8') as file:
        output = csv.writer(file)
        output.writerow(['strategy', 'query', 'score', 'id', 'document', 'offset', 'text'])

        for method in ['window0', 'window10', 'sentence']:
            chunks = make_corpus(method)
            hits = 0
            rank_score = 0
            start_time = time.time()

            for question, wanted_document in final:
                results = search(question, chunks)
                positions = []
                for position, result in enumerate(results, 1):
                    if result[1][1] == wanted_document:
                        positions.append(position)
                if positions:
                    hits += 1
                    rank_score += 1 / positions[0]

            print(method, 'Hit@3:', round(hits / 4, 2), 'MRR@3:', round(rank_score / 4, 2), 'time:', round(time.time() - start_time, 4))

            for question, wanted_document in development + final:
                for score, chunk in search(question, chunks):
                    output.writerow([method, question, round(score, 4), chunk[0], chunk[1], chunk[2], chunk[3]])

    print('Development:', len(development), 'Final:', len(final), 'Unanswerable:', len(unknown))
    print('Token lengths:', [len(get_words(x[3])) for x in make_corpus('sentence')[:5]])
    print('CSV: lab6_results.csv')

    try:
        from sentence_transformers import SentenceTransformer
        start_time = time.time()
        SentenceTransformer('all-MiniLM-L6-v2')
        print('Real embedding model load time:', round(time.time() - start_time, 2))
    except Exception:
        print('Install sentence-transformers for real embeddings.')


main()
